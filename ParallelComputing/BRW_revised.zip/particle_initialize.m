function part_system = particle_initialize( param )
%% Initialize one particle carrying a few elements

%% establish a struct 'part' for particles
part_system = struct;

% particle number
part_system.num = param.Np;

% the position of particle
if(param.case == 0) % Gaussian distribution
  part_system.pos = randn(param.Np, param.d);
elseif(param.case == 1) % Poisson point process
  part_system.pos = poissrnd(param.lambda, param.Np, param.d);
end

% the weight of particle
part_system.weight = zeros(param.Np, param.d);

% the life(generation) of the particle
part_system.life = zeros(param.Np, param.d);

% the waiting time
part_system.wait = zeros(param.Np, param.d);

end



