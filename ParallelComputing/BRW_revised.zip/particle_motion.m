function part_system = particle_motion( part_system, param )
%% Simulate the motion of 'idx'-th particle

% the position of particle (Default: random walk)
Np = part_system.num;
part_system.pos = part_system.pos + randn(Np, param.d)*param.dt - param.c*param.dt; 

% the weight of particle
part_system.weight = part_system.weight;

% the life(generation) of the particle
part_system.life = part_system.life + param.dt;
part_system.wait = part_system.wait + param.dt;

end