%% main program of simulating particle dynamics
run('parameters.m')

%% Step 1: Initialize the particle system
part_system = particle_initialize( param );
figure 
hold on
box on
axis([0 10 -inf inf])
%histogram( part_system.pos, 'normalization', 'probability')



scatter(part_system.life, part_system.pos, 'filled')

for l = 1:param.Nstep
  tic
  part_system = particle_motion( part_system, param );
  part_system = particle_generation( part_system, param );

  %% control the particle number
  if(mod(l, param.Nkill) == 0)
    part_system_post = particle_death( part_system, param );
    fprintf('Particle number before killing: %d and after killing: %d\n', ...
      part_system.num, part_system_post.num);
    part_system = part_system_post;
  end
  
  %% output the results
  if(mod(l, param.Nplot) == 0)
    scatter(part_system.life, part_system.pos, 'filled')
    fprintf('%d step completed, particle number:%d ', l, part_system.num)  
    toc
  end
end

figure
histogram( part_system.pos, 'normalization', 'probability')

