function part_system_post = particle_death( part_system, param )
%% Kill the p the motion of 'idx'-th particle

%% establish a struct 'part' for particles
part_system_post = struct;
part_system_post.num = 0;

for i = 1:part_system.num
  %% Keep the particles when their positions exceed the threshold
  if(part_system.pos(i) > param.threshold)
    part_system_post.num = part_system_post.num + 1;
    
    %  add a new particle at the end of particle system
    part_system_post.pos(part_system_post.num, :)    = part_system.pos(i, :);
    part_system_post.weight(part_system_post.num) = part_system.weight(i);
    part_system_post.life(part_system_post.num)   = part_system.life(i);
    part_system_post.wait(part_system_post.num)   = part_system.wait(i);
  end
end




end