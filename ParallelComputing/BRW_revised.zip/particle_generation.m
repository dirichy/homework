function part_system = particle_generation( part_system, param )
%% Simulate the motion of 'idx'-th particle

r    = exprnd(param.lambda, part_system.num, 1);
Np   = part_system.num;

%% branching event
for idx = 1:Np
  if(part_system.wait(idx) > r(idx))
    part_system.wait(idx) = 0;
    part_system.num       = part_system.num + 1;
  
    %  add a new particle at the end of particle system
    part_system.pos(part_system.num, :) = part_system.pos(idx, :);
    part_system.weight(part_system.num) = part_system.weight(idx);
    part_system.life(part_system.num)   = part_system.life(idx);
    part_system.wait(part_system.num)   = part_system.wait(idx);
  end
end

end