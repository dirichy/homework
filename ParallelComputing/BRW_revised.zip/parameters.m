%% parameters
param.Np     = 10000;
param.d      = 1;
param.lambda = 1; %% intensity of Poisson process  
param.c      = 1;
param.dt     = 0.1; % time step

%% killing parameters
param.Nkill     = 5;
param.threshold = -1; %% kill all the particles below -1

param.Nstep  = 50;
param.Nplot  = 5;  % plot the point cloud every five steps


%initial state
param.case = 1;




